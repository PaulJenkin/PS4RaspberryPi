# brcmfmac_sdio-firmware-rpi

Useful alternative source for RPi/Broadcom firmwares:

WiFi: https://github.com/RPi-Distro/firmware-nonfree/tree/master/brcm
Bluetooth: https://github.com/RPi-Distro/bluez-firmware/tree/master/broadcom

# WiFi Firmware Version

- Broadcom BCM43430 firmware v7.45.98.38
- Broadcom BCM43455 firmware v7.45.154

# License

Licence: Redistributable. See LICENCE.broadcom_bcm43xx for details.
