/*
 * This is just a dummy test which checks if all our headers
 * compiles correctly with a C++ compiler.
 */

#include <usbg/usbg.h>
#include <usbg/function/ffs.h>
#include <usbg/function/hid.h>
#include <usbg/function/loopback.h>
#include <usbg/function/midi.h>
#include <usbg/function/ms.h>
#include <usbg/function/net.h>
#include <usbg/function/phonet.h>
#include <usbg/function/serial.h>
#include <usbg/function/uac2.h>

int main(int argc, char **argv)
{
	return 0;
}
